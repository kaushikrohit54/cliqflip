<?php

namespace UxBuilder\Collections;

class Components extends Collection {
  
}
